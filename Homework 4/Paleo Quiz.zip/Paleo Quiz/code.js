// Variables
var score = 0;
var questionIndex = 0;

// Questions Array
var questions = [
  {
    question: "Which period did the Tyrannosaurus rex live in?",
    choices: ["Jurassic", "Triassic", "Cretaceous"],
    answer: "Cretaceous"
  },
  {
    question: "What does the word 'fossil' mean?",
    choices: ["Ancient bone", "Dug up", "Stone creature"],
    answer: "Dug up"
  },
  {
    question: "What type of fossil is formed when minerals replace all or part of an organism?",
    choices: ["Mold fossil", "Cast fossil", "Petrified fossil"],
    answer: "Petrified fossil"
  },
  {
    question: "Which scientist is known for developing the theory of extinction through catastrophic events?",
    choices: ["Charles Darwin", "Georges Cuvier", "Mary Anning"],
    answer: "Georges Cuvier"
  },
  ({
    question: "What is the name of the ancient supercontinthat existed during the late Paleozoic and early Mesozoic erasent?",
    choices: ["Gondwana", "Pangaea", "Laurasia"],
    answer: "Pangaea"
  })
];

// Start Button
onEvent("startButton", "click", function() {
  score = 0;
  questionIndex = 0;
  setScreen("questionScreen");
  showQuestion();
});

// Show Question
function showQuestion() {
  setText("questionLabel", questions[questionIndex].question);
  setText("choice1", questions[questionIndex].choices[0]);
  setText("choice2", questions[questionIndex].choices[1]);
  setText("choice3", questions[questionIndex].choices[2]);
  setText("feedbackLabel", "");
}

// Answer Buttons
onEvent("choice1", "click", function() { checkAnswer(getText("choice1")); });
onEvent("choice2", "click", function() { checkAnswer(getText("choice2")); });
onEvent("choice3", "click", function() { checkAnswer(getText("choice3")); });

// Check Answer
function checkAnswer(choice) {
  if (choice == questions[questionIndex].answer) {
    score++;
    setText("feedbackLabel", "Correct!");
  } else {
    setText("feedbackLabel", "Try again!");
  }

  // Delay before next question
  setTimeout(function() {
    questionIndex++;
    if (questionIndex < questions.length) {
      showQuestion();
    } else {
      showResult();
    }
  }, 1000);
}

// Show Result
function showResult() {
  setScreen("resultScreen");
  setText("scoreLabel", "You scored " + score + " out of 5");
  if (score >= 3) {
    setText("resultLabel", "You win!");
  } else {
    setText("resultLabel", "Better luck next time!");
  }
}

// Play Again Button
onEvent("playAgainButton", "click", function() {
  setScreen("startScreen");
});
